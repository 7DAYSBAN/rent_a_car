﻿namespace Rent_A_Car.Enums
{
    public enum Roles
    {
        Admin,
        User
    }
}
